# 🌾 Plateforme d'Analyse Agricole IA - Package de Déploiement

## 🚀 Déploiement Rapide sur Streamlit Cloud

### Étape 1: GitHub
1. Créez un nouveau repository sur GitHub (public)
2. Uploadez tous ces fichiers dans le repository
3. Commitez avec "Initial commit"

### Étape 2: Streamlit Cloud
1. Allez sur https://share.streamlit.io
2. Connectez votre GitHub
3. Sélectionnez votre repository
4. Fichier principal: `app.py`
5. Cliquez "Deploy!"

### Étape 3: Configuration
L'application utilise `setup_requirements.txt` pour les dépendances.
Streamlit Cloud installera automatiquement tous les packages nécessaires.

## 📱 URL de votre Application
Votre app sera disponible à: `https://[nom-choisi].streamlit.app`

## ✅ Fonctionnalités Incluses
- Dashboard agricole interactif
- Prédictions IA (Random Forest, XGBoost)
- Analyse météorologique
- Surveillance du sol
- Détection des maladies
- Upload de données CSV/Excel

## 📊 Données Incluses
- 500 enregistrements agricoles
- 365 jours de données météo
- 155 mesures de sol
- Modèles IA pré-entraînés

## 🆓 Coût Total: 0€
- GitHub: Gratuit (repository public)
- Streamlit Cloud: Gratuit
- Domaine: Inclus (.streamlit.app)

## 📞 Support
En cas de problème:
1. Vérifiez que tous les fichiers sont uploadés
2. Repository doit être PUBLIC
3. Fichier principal: app.py
4. Redéployez si nécessaire

Temps de déploiement: 2-3 minutes
